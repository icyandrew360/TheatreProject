# TheatreProject
A java application that could be used to fufill an online movie ticket reservation/purchasing process for a Movie Theatre


## Contributors

 - Andrew Howe
 - James Platt
 - Jenna Vlaar 
 - Sadman Shahriar



## HOW TO RUN THE PROGRAM

1. Set up a database with the format specified in src/db/theatre-db.sql 
   Run a MySQL Database server, the provided database can be used. 
   
2. Run the program with the packaged .jar file.


